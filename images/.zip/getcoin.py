import json
import requests
import time


def download_img(img_url,file_name):
    if img_url is None:
        print("image_url is null,"+file_name)
    r = requests.get(img_url, stream=True)
    print(r.status_code) # 返回状态码
    if r.status_code == 200:
        open('./images/'+file_name, 'wb').write(r.content) # 将内容写入图片
        print("done")
    del r

sql = "INSERT INTO `wallet_coin` (`coin_id`, `name`, `symbol`, `account_type`, `decimal_num`, `v_decimal_num`, `base_coin_id`, `okex_coin_id`, `address`, `rank`, `coin_type`, `is_visible`, `image_url`, `s_image_url`, `is_delete`, `block_height`, `support_version`, `is_default`) VALUES (%s, '%s', '%s', '1', '%s', '5', '1800', '%s', '%s', '100000', '128', '0', '%s', '%s',  '0', '0', '200010000', '0');"
count = 0
id = 2501
file = open("./solana.tokens.json", "r")
j = file.read()
jsonObject = json.loads(str(j))
l = []
for item in jsonObject["tokens"]:
    # print(item)
    count = count+1
    if id>3658 and dict(item).__contains__("logoURI") and item["logoURI"]!="":
        s = sql %(id,item["name"],item["symbol"],item["decimals"],-id,item["address"],item["logoURI"],item["logoURI"])
        l.append(item["logoURI"])
        sub = str(item["logoURI"]).split(".")
        img_part = sub.pop()
        if img_part.__contains__("/"):
            print("error image:",item['logoURI'],"  ",id)
        else:
            download_img(item["logoURI"],"solana"+str(id)+"."+img_part)
            time.sleep(1)
    else:
        s = sql %(id,item["name"],item["symbol"],item["decimals"],-id,item["address"],"https://static.coinall.ltd/cdn/wallet/logo/icon_unknow.png","https://static.coinall.ltd/cdn/wallet/logo/icon_unknow.png")
    print(s)
    id = id + 1
print(count)
print(l)

#https://static.coinall.ltd/cdn/wallet/logo/axion.svg
